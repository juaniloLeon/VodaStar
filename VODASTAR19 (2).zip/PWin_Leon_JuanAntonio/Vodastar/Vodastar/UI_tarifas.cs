﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;


namespace Vodastar
{
    public partial class UI_tarifas : Form
    {
        Tarifa tarifa;
        datTarifa verTarifa;

        public UI_tarifas()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UI_tarifas_Load(object sender, EventArgs e)
        {

            MinimumSize = this.Size;
            MaximumSize = this.Size;
            dgv.DataSource = LNyAD.ObtenTodasTarifas();

            dgv.Columns["idTarifa"].Visible = false;

            this.Text = "Tarifa";

           

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            verTarifa = new datTarifa();
            tarifa = new Tarifa();
            verTarifa.Tarifa = tarifa;
            if (verTarifa.ShowDialog() == DialogResult.Yes)
            {
                LNyAD.ActualizarAnyadirRegistro(tarifa);
                dgv.DataSource = LNyAD.ObtenTodasTarifas();

            }



        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int editar;
            int idTarifa;
            int colIdTarifa;
            editar = dgv.Columns["Editar"].Index;
            int colBorrar;
            colBorrar = dgv.Columns["Eliminar"].Index;
            colIdTarifa = dgv.Columns["idTarifa"].Index;
            Tarifa tarifa;



            if (e.RowIndex > -1 && e.RowIndex < dgv.RowCount - 1)
            {

                string aux = dgv[colIdTarifa, e.RowIndex].Value.ToString();
                idTarifa = Convert.ToInt32(aux);
                tarifa = LNyAD.ObtenTarifaPorID(idTarifa.ToString());
                if (e.ColumnIndex == editar)//Editar
                {

                    verTarifa = new datTarifa();
                    verTarifa.Tarifa = tarifa;



                    if (verTarifa.ShowDialog() == DialogResult.Yes)
                    {
                        LNyAD.ActualizarAnyadirRegistro(tarifa);
                        dgv.DataSource = LNyAD.ObtenTodasTarifas();
                        
                    }

                }
                else if (e.ColumnIndex == colBorrar)
                {
                    if (LNyAD.ExisteConsumoDeTarifa(dgv[colIdTarifa, e.RowIndex].Value.ToString()))
                        MessageBox.Show("No se puede eliminar, ya hay consumos asociados", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    else
                    {
                        if(MessageBox.Show("Desea borrar la tarifa " + tarifa.Nombre + "?", "ERROR", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            LNyAD.BorrarTarifa(tarifa);
                            dgv.DataSource = LNyAD.ObtenTodasTarifas();

                        }
                    }
                }
            }
        }
    }
}
