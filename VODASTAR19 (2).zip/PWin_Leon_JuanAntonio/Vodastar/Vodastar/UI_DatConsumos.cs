﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;


namespace Vodastar
{
    public partial class UI_DatConsumos : Form
    {
        Cliente cliente;
        List<Tarifa> datosTarifas = new List<Tarifa>();
        NewConsumo newConsumo;
        Consumo cons;
        int tipo;//1 usuario concreto 0 todos usuarios

        public Cliente Cliente
        {
            get
            {
                return cliente;
            }

            set
            {
                cliente = value;
            }
        }

        public UI_DatConsumos()
        {
            InitializeComponent();
        }
        public UI_DatConsumos(int i)
        {

            InitializeComponent();
            tipo = i;
        }


        private void UI_DatConsumos_Load(object sender, EventArgs e)
        {


            MinimumSize = this.Size;
            MaximumSize = this.Size;

            if (tipo == 1)
            {
                dgv.DataSource = LNyAD.ObtenerConsumos(cliente.IdCliente);
                dgv.Columns["Origen"].Visible = false;
            }
            else
            {
                dgv.DataSource = LNyAD.ObtenerConsumos();
                dgv.Columns["Origen"].Visible = true;

            }

            dgv.Columns["idConsumo"].Visible = false;
            dgv.Columns["idTarifa"].Visible = false;
            dgv.Columns["idCliente"].Visible = false;



            dgv.Columns["FechaHora"].DisplayIndex = 1;
            dgv.Columns["Destino"].DisplayIndex = 2;
            dgv.Columns["Duracion"].DisplayIndex = 3;
            dgv.Columns["Total"].DisplayIndex = 4;


            dgv.Columns["FechaHora"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dgv.Columns["Destino"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Duracion"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Tarifa"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            cbTarifa.Items.Add("Todas");
            vodastarDataSet.TarifasDataTable tarifas = LNyAD.ObtenTodasTarifas();
            for (int i = 0; i < tarifas.Count; i++)
            {
                datosTarifas.Add(new Tarifa(tarifas[0]));
                cbTarifa.Items.Add(tarifas[i].Nombre);
            }
            cbTarifa.SelectedIndex = 0;

        }

      

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
      
        private void btnNew_Click(object sender, EventArgs e)
        {
            newConsumo = new NewConsumo();
            cons = new Consumo();
            newConsumo.Cliente = cliente;
            newConsumo.Cons = cons;
            if (newConsumo.ShowDialog() == DialogResult.Yes)
            {
                LNyAD.ActualizarAnyadirRegistro(cons);
                ActualizaDGV();
            }
        }

        private void cbTarifa_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbTarifa.SelectedIndex != 0)
            {
                int idTarifa = LNyAD.ObtenTarifaPorNombre(cbTarifa.Text).IdTarifa;

                if (tipo == 1)
                {
                    dgv.DataSource = LNyAD.ObtenerConsumos(cliente.IdCliente, idTarifa);

                }
                else
                {
                    dgv.DataSource = LNyAD.ObtenerConsumosDeTarifa(idTarifa);
                    
                }
                dgv.Columns["Tarifa"].Visible = false;
                RellenaTotal();
            }
            else
            {
                dgv.Columns["Tarifa"].Visible = true;

                if (tipo == 1)
                {
                    dgv.DataSource = LNyAD.ObtenerConsumos(cliente.IdCliente);
               
                }
                else
                    dgv.DataSource = LNyAD.ObtenerConsumos();
                RellenaDatos();
            }

            if (tipo != 1)
                RellenaOrigen();

        }

        private void RellenaOrigen()
        {

            int colIDCliente = dgv.Columns["idCliente"].Index;
            int colOrigen = dgv.Columns["Origen"].Index;
            int idCliente = 0;


            for (int i = 0; i < dgv.Rows.Count - 1; i++)
            {
                
                idCliente=Convert.ToInt32(dgv[colIDCliente, i].Value.ToString());
                dgv[colOrigen, i].Value = LNyAD.ObtenNumero(idCliente);

            }
        }

        private void RellenaDatos()
        {
            int colIDTarifa = dgv.Columns["idTarifa"].Index;
            int colIDTotal = dgv.Columns["Total"].Index;
            int colIDConsumo = dgv.Columns["idConsumo"].Index;

            int colTarifa = dgv.Columns["Tarifa"].Index;
            


            for (int i = 0; i < dgv.Rows.Count - 1; i++)
            {
                dgv[colTarifa, i].Value = LNyAD.ObtenTarifaPorID(dgv[colIDTarifa, i].Value.ToString()).Nombre;

                

                dgv[colIDTotal, i].Value = LNyAD.SumaConsumo(dgv[colIDConsumo,i].Value.ToString());

            }
            dgv.Columns["Total"].DisplayIndex = 4;


        }
        private void RellenaTotal()
        {
            int colIDTotal = dgv.Columns["Total"].Index;
            int colIDConsumo = dgv.Columns["idConsumo"].Index;
            for (int i = 0; i < dgv.Rows.Count - 1; i++)
            {



                dgv[colIDTotal, i].Value = LNyAD.SumaConsumo(dgv[colIDConsumo, i].Value.ToString());
            }


        }
        private void ActualizaDGV()
        {
            int a = cbTarifa.SelectedIndex;
            cbTarifa.SelectedIndex = 0;
            cbTarifa.SelectedIndex = 1;
            cbTarifa.SelectedIndex = a;


        }


    }
}
