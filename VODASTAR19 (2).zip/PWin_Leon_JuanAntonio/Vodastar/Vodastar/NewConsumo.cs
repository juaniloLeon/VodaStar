﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;

namespace Vodastar
{
    public partial class NewConsumo : Form
    {
        Consumo cons;
        Cliente cliente;
        public Consumo Cons
        {
            get
            {
                return cons;
            }

            set
            {
                cons= value;
            }
        }
        public Cliente Cliente
        {
            get
            {
                return cliente;
            }

            set
            {
                cliente = value;
            }
        }


        public NewConsumo()
        {
            InitializeComponent();
        }

        

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int a;

            if(txbDestino.Text.Equals(string.Empty)|| txbDuracion.Text.Equals(string.Empty))
            {
                MessageBox.Show("Todos los campos son obligatorios");
                return;
            }

            if (!LNyAD.FormaTelefono(txbDestino.Text)&&Int32.TryParse(txbDuracion.Text, out a)&&a>0)
                MessageBox.Show("Revise los campos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                
                cons.Destino = txbDestino.Text;
                cons.Duracion = txbDuracion.Text;
                cons.IdTarifa = LNyAD.ObtenTarifaPorNombre(cbTarifa.Text).IdTarifa;
                cons.FechaHora = new DateTime().ToString();

                if (cliente.IdCliente < 0)

                    cons.IdCliente = LNyAD.ObtenClientePorDNI(cbCliente.Text).IdCliente;
                else
                    cons.IdCliente = cliente.IdCliente;
                DialogResult=MessageBox.Show("¿Desea añadir el registro?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            }


        }

        private void NewConsumo_Load(object sender, EventArgs e)
        {

            MinimumSize = this.Size;
            MaximumSize = this.Size;
            vodastarDataSet.TarifasDataTable tarifas = LNyAD.ObtenTodasTarifas();
            for (int i = 0; i < tarifas.Count; i++)
            {
                
                cbTarifa.Items.Add(tarifas[i].Nombre);
            }
            cbTarifa.SelectedIndex = 0;


            if (cliente.IdCliente < 0)
            {
                txbCliente.Visible = false;
                cbCliente.Visible = true;

                vodastarDataSet.ClientesDataTable clientes = LNyAD.ObtenerClientes();
                for (int i = 0; i < clientes.Count; i++)
                {
                    cbCliente.Items.Add(clientes[i].DNI);
                }
                cbCliente.SelectedIndex = 0;
            }
            else
            {
                txbCliente.Visible = true;
                cbCliente.Visible = false;

                txbCliente.Enabled = false;
                txbCliente.Text = cliente.Dni;

            }

        }
    }
}
