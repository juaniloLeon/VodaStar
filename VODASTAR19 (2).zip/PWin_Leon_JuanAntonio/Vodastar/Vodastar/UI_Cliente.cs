﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;

namespace Vodastar
{
    public partial class UI_Cliente : Form
    {
        Cliente quienSoy;
        List<Tarifa> datosTarifas = new List<Tarifa>();

        public Cliente QuienSoy
        {
            get
            {
                return quienSoy;
            }

            set
            {
                quienSoy = value;
            }
        }



        public UI_Cliente()
        {
            InitializeComponent();
        }

       

        private void UI_Cliente_Load(object sender, EventArgs e)
        {

            MinimumSize = this.Size;
            MaximumSize = this.Size;

            dgv.DataSource = LNyAD.ObtenerConsumos(quienSoy.IdCliente);
            dgv.Columns["idConsumo"].Visible = false;
            dgv.Columns["idTarifa"].Visible = false;
            dgv.Columns["idCliente"].Visible = false;



            dgv.Columns["FechaHora"].DisplayIndex = 1;
            dgv.Columns["Destino"].DisplayIndex = 2;
            dgv.Columns["Duracion"].DisplayIndex = 3;

            dgv.Columns["FechaHora"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dgv.Columns["Destino"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Duracion"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Tarifa"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            cbTarifa.Items.Add("Todas");
            vodastarDataSet.TarifasDataTable tarifas = LNyAD.ObtenTodasTarifas();
            for (int i = 0; i < tarifas.Count; i++)
            {
                datosTarifas.Add(new Tarifa(tarifas[0]));
                cbTarifa.Items.Add(tarifas[i].Nombre);
            }
            cbTarifa.SelectedIndex = 0;

            lbTotales.Text = LNyAD.TotalDeTotales(quienSoy.IdCliente.ToString())+"€";
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbTarifa_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cbTarifa.SelectedIndex != 0)
            {

                int idTarifa = LNyAD.ObtenTarifaPorNombre(cbTarifa.Text).IdTarifa;
                dgv.DataSource = LNyAD.ObtenerConsumos(quienSoy.IdCliente,idTarifa);
                dgv.Columns["Tarifa"].Visible = false;
                RellenaTotal();
            }
            else
            {
                dgv.Columns["Tarifa"].Visible = true;

                dgv.DataSource = LNyAD.ObtenerConsumos(quienSoy.IdCliente);
                RellenaDatos();
            }


        }

        private void RellenaDatos()
        {
            int colIDTarifa = dgv.Columns["idTarifa"].Index;
            int colTarifa = dgv.Columns["Tarifa"].Index;
            int colIDTotal = dgv.Columns["Total"].Index;
            int colIDConsumo = dgv.Columns["idConsumo"].Index;
            for (int i = 0; i < dgv.Rows.Count - 1; i++)
            {
                dgv[colTarifa, i].Value = LNyAD.ObtenTarifaPorID(dgv[colIDTarifa, i].Value.ToString()).Nombre;


                dgv[colIDTotal, i].Value = LNyAD.SumaConsumo(dgv[colIDConsumo, i].Value.ToString());
            }


        }
        private void RellenaTotal()
        {
            int colIDTotal = dgv.Columns["Total"].Index;
            int colIDConsumo = dgv.Columns["idConsumo"].Index;
            for (int i = 0; i < dgv.Rows.Count - 1; i++)
            {
               


                dgv[colIDTotal, i].Value = LNyAD.SumaConsumo(dgv[colIDConsumo, i].Value.ToString());
            }


        }
        UI_DatCliente misDatos;

        private void btnDatos_Click(object sender, EventArgs e)
        {
            misDatos = new UI_DatCliente(quienSoy.Tipo);
            misDatos.Cliente = quienSoy;
            if (misDatos.ShowDialog() == DialogResult.Yes)
                LNyAD.ActualizarAnyadirRegistro(quienSoy);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("HAS ENCONTRADO EL MENSAJE SORPRESA","FELICIDADES",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
        }
    }
}
