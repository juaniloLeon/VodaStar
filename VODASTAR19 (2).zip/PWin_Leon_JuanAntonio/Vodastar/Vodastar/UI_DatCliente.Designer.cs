﻿namespace Vodastar
{
    partial class UI_DatCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txbName = new System.Windows.Forms.TextBox();
            this.lbName = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.lbSurname = new System.Windows.Forms.Label();
            this.txbSurname = new System.Windows.Forms.TextBox();
            this.lbDNI = new System.Windows.Forms.Label();
            this.txbDNI = new System.Windows.Forms.TextBox();
            this.lbMail = new System.Windows.Forms.Label();
            this.txbMail = new System.Windows.Forms.TextBox();
            this.lbTlf = new System.Windows.Forms.Label();
            this.txbTlf = new System.Windows.Forms.TextBox();
            this.lbPass = new System.Windows.Forms.Label();
            this.txbPass = new System.Windows.Forms.TextBox();
            this.cbxStatus = new System.Windows.Forms.ComboBox();
            this.lbStatus = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnOtro = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txbName
            // 
            this.txbName.Location = new System.Drawing.Point(12, 44);
            this.txbName.Name = "txbName";
            this.txbName.Size = new System.Drawing.Size(141, 20);
            this.txbName.TabIndex = 0;
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(9, 28);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(44, 13);
            this.lbName.TabIndex = 1;
            this.lbName.Text = "Nombre";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(12, 171);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(141, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Guardar";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(179, 171);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(140, 23);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Cancelar";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // lbSurname
            // 
            this.lbSurname.AutoSize = true;
            this.lbSurname.Location = new System.Drawing.Point(9, 73);
            this.lbSurname.Name = "lbSurname";
            this.lbSurname.Size = new System.Drawing.Size(49, 13);
            this.lbSurname.TabIndex = 5;
            this.lbSurname.Text = "Apellidos";
            // 
            // txbSurname
            // 
            this.txbSurname.Location = new System.Drawing.Point(12, 89);
            this.txbSurname.Name = "txbSurname";
            this.txbSurname.Size = new System.Drawing.Size(141, 20);
            this.txbSurname.TabIndex = 1;
            // 
            // lbDNI
            // 
            this.lbDNI.AutoSize = true;
            this.lbDNI.Location = new System.Drawing.Point(9, 117);
            this.lbDNI.Name = "lbDNI";
            this.lbDNI.Size = new System.Drawing.Size(26, 13);
            this.lbDNI.TabIndex = 7;
            this.lbDNI.Text = "DNI";
            // 
            // txbDNI
            // 
            this.txbDNI.Location = new System.Drawing.Point(12, 133);
            this.txbDNI.Name = "txbDNI";
            this.txbDNI.Size = new System.Drawing.Size(141, 20);
            this.txbDNI.TabIndex = 2;
            // 
            // lbMail
            // 
            this.lbMail.AutoSize = true;
            this.lbMail.Location = new System.Drawing.Point(176, 28);
            this.lbMail.Name = "lbMail";
            this.lbMail.Size = new System.Drawing.Size(32, 13);
            this.lbMail.TabIndex = 9;
            this.lbMail.Text = "eMail";
            // 
            // txbMail
            // 
            this.txbMail.Location = new System.Drawing.Point(179, 44);
            this.txbMail.Name = "txbMail";
            this.txbMail.Size = new System.Drawing.Size(141, 20);
            this.txbMail.TabIndex = 3;
            // 
            // lbTlf
            // 
            this.lbTlf.AutoSize = true;
            this.lbTlf.Location = new System.Drawing.Point(176, 73);
            this.lbTlf.Name = "lbTlf";
            this.lbTlf.Size = new System.Drawing.Size(95, 13);
            this.lbTlf.TabIndex = 11;
            this.lbTlf.Text = "Teléfono asociado";
            // 
            // txbTlf
            // 
            this.txbTlf.Location = new System.Drawing.Point(179, 89);
            this.txbTlf.Name = "txbTlf";
            this.txbTlf.Size = new System.Drawing.Size(92, 20);
            this.txbTlf.TabIndex = 4;
            // 
            // lbPass
            // 
            this.lbPass.AutoSize = true;
            this.lbPass.Location = new System.Drawing.Point(176, 117);
            this.lbPass.Name = "lbPass";
            this.lbPass.Size = new System.Drawing.Size(34, 13);
            this.lbPass.TabIndex = 13;
            this.lbPass.Text = "Clave";
            // 
            // txbPass
            // 
            this.txbPass.Location = new System.Drawing.Point(179, 133);
            this.txbPass.Name = "txbPass";
            this.txbPass.PasswordChar = '•';
            this.txbPass.Size = new System.Drawing.Size(72, 20);
            this.txbPass.TabIndex = 5;
            // 
            // cbxStatus
            // 
            this.cbxStatus.FormattingEnabled = true;
            this.cbxStatus.Location = new System.Drawing.Point(259, 133);
            this.cbxStatus.Name = "cbxStatus";
            this.cbxStatus.Size = new System.Drawing.Size(60, 21);
            this.cbxStatus.TabIndex = 14;
            this.cbxStatus.SelectedIndexChanged += new System.EventHandler(this.cbxStatus_SelectedIndexChanged);
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.Location = new System.Drawing.Point(256, 117);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(40, 13);
            this.lbStatus.TabIndex = 15;
            this.lbStatus.Text = "Estado";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(179, 133);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(72, 20);
            this.btnReset.TabIndex = 16;
            this.btnReset.Text = "Reiniciar";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnOtro
            // 
            this.btnOtro.Location = new System.Drawing.Point(277, 89);
            this.btnOtro.Name = "btnOtro";
            this.btnOtro.Size = new System.Drawing.Size(42, 20);
            this.btnOtro.TabIndex = 17;
            this.btnOtro.Text = "↻";
            this.btnOtro.UseVisualStyleBackColor = true;
            this.btnOtro.Click += new System.EventHandler(this.btnOtro_Click);
            // 
            // UI_DatCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 211);
            this.Controls.Add(this.btnOtro);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lbStatus);
            this.Controls.Add(this.cbxStatus);
            this.Controls.Add(this.lbPass);
            this.Controls.Add(this.txbPass);
            this.Controls.Add(this.lbTlf);
            this.Controls.Add(this.txbTlf);
            this.Controls.Add(this.lbMail);
            this.Controls.Add(this.txbMail);
            this.Controls.Add(this.lbDNI);
            this.Controls.Add(this.txbDNI);
            this.Controls.Add(this.lbSurname);
            this.Controls.Add(this.txbSurname);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.txbName);
            this.Name = "UI_DatCliente";
            this.Text = "Ficha Cliente";
            this.Load += new System.EventHandler(this.UI_DatCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txbName;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lbSurname;
        private System.Windows.Forms.TextBox txbSurname;
        private System.Windows.Forms.Label lbDNI;
        private System.Windows.Forms.TextBox txbDNI;
        private System.Windows.Forms.Label lbMail;
        private System.Windows.Forms.TextBox txbMail;
        private System.Windows.Forms.Label lbTlf;
        private System.Windows.Forms.TextBox txbTlf;
        private System.Windows.Forms.Label lbPass;
        private System.Windows.Forms.TextBox txbPass;
        private System.Windows.Forms.ComboBox cbxStatus;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnOtro;
    }
}