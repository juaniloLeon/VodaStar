﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;


namespace Vodastar
{
    public partial class UI_DatCliente : Form
    {
        int editMode; //0 solicitar alta - 1 modo Admin - 2 modo User
        Cliente cliente;
        int tipo;

        public Cliente Cliente
        {
            get
            {
                return cliente;
            }

            set
            {
                cliente = value;
            }
        }

        public UI_DatCliente()
        {
            InitializeComponent();
            editMode = 0;
        }
        public UI_DatCliente(int editMode)
        {
            InitializeComponent();
            this.editMode = editMode;
        }

        private void UI_DatCliente_Load(object sender, EventArgs e)
        {
            txbDNI.Text = cliente.Dni;
            txbMail.Text = cliente.Email;
            txbName.Text = cliente.Nombre;
            txbSurname.Text = cliente.Apellidos;
            txbTlf.Text = cliente.Telefono;
            txbPass.Text = cliente.Clave;

            MinimumSize = this.Size;
            MaximumSize = this.Size;



            cbxStatus.Items.Add("Baja");
            cbxStatus.Items.Add("Activo");
            cbxStatus.Items.Add("Administrador");

            SelectStatus();


            switch (editMode)
            {
                case 0: //solicitud alta
                    btnReset.Visible = false;
                    btnReset.Enabled = false;
                    this.Text = "Solicitar Alta";
                    cbxStatus.Visible = false;
                    cbxStatus.Enabled = false;
                    lbStatus.Visible = false;
                    txbTlf.Enabled = false;
                    txbTlf.Text = LNyAD.NumeroDisponible();
                    tipo = 0;
                    txbPass.Text = "";
                    break;
                case 1: //Admin
                    txbPass.Enabled = false;
                    txbPass.Visible = false;
                    txbDNI.Enabled = false;

                    if (cliente.IdCliente > 0)
                    {
                        txbTlf.Enabled = false;
                        btnOtro.Enabled = false;
                        btnOtro.Visible = false;
                    }

                    break;
                case 2: // user
                    btnReset.Visible = false;
                    btnReset.Enabled = false;
                    txbDNI.Enabled = false;
                    txbName.Enabled = false;
                    txbSurname.Enabled = false;
                    txbTlf.Enabled = false;
                    cbxStatus.Visible = false;
                    cbxStatus.Enabled = false;
                    lbStatus.Visible = false;
                    btnOtro.Enabled = false;
                    btnOtro.Visible = false;
                    break;
                default: //Fallo en el sistema
                    MessageBox.Show("Se ha detectado un error en el sistema", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    break;

            }
            if (cliente.IdCliente < 0)
                txbDNI.Enabled = true;
        }

        private void SelectStatus()
        {
            string aux = cliente.Tipo.ToString();
            int tipo = Convert.ToInt32(aux);

            switch (tipo)
            {
                case 0:
                    cbxStatus.SelectedIndex = 0;
                    break;
                case 1:
                    cbxStatus.SelectedIndex = 2;
                    break;
                case 2:
                    cbxStatus.SelectedIndex = 1;
                    break;
                default: goto case 0;

            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txbPass.Text = "pordefecto";

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            txbDNI.Text = txbDNI.Text.ToUpper();
            if (verificaDatos(cliente))
            {
                cliente.Apellidos = txbSurname.Text;
                cliente.Nombre = txbName.Text;
                cliente.Dni = txbDNI.Text;
                cliente.Tipo = tipo;
                cliente.Telefono = txbTlf.Text;
                cliente.Clave = txbPass.Text;
                cliente.Email = txbMail.Text;
                if (DialogResult.Yes == MessageBox.Show("¿Desea guardar con los datos introducidos?", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {
                    DialogResult = DialogResult.Yes;
                    this.Close();
                }

            }


        }

        private bool verificaDatos(Cliente cliente)
        {

            TransformaDNI(txbDNI);

            String error = string.Empty;
            bool formatos = false;
            bool existe = false;


            if (txbDNI.Text.Equals(string.Empty) ||
                txbMail.Text.Equals(string.Empty) ||
                txbName.Text.Equals(string.Empty) ||
                txbSurname.Text.Equals(string.Empty) ||
                txbPass.Text.Equals(string.Empty) ||
                txbTlf.Text.Equals(string.Empty)
                )
            {
                MessageBox.Show("Hay campos vacios\nTodos los campos son obligatorios","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
                               
            }
            if (!LNyAD.FormaEmail(txbMail.Text))
            {
                formatos = true;
                error += "El formato del eMail es incorrecto\n";
            }
            if (!LNyAD.FormaDNI(txbDNI.Text))
            {
                if (!UsuariosProtected(txbDNI.Text))
                {
                    formatos = true;
                    error += "El formato del DNI es incorrecto\n";
                }
            }
            if (!LNyAD.FormaTelefono(txbTlf.Text))
            {
                formatos = true;
                error += "El formato del Teléfono es incorrecto\n";
            }

            if (formatos)
            {
                MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            error = String.Empty;

            if(!LNyAD.ExisteTelefono(Convert.ToInt32(txbTlf.Text), cliente.IdCliente))
            {
                existe = true;
                error += "El numero solicitado ya está asignado\n";
            }
            if (!LNyAD.ExisteMail(txbMail.Text, cliente.IdCliente))
            {
                existe = true;
                error += "El mail introducido ya está registrado\n";
            }
            if (!LNyAD.ExisteDNI(txbDNI.Text, cliente.IdCliente))
            {
                existe = true;
                error += "El DNI introducido ya está registrado\n";
            }


            if (existe)
            {
                MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            return true;
        }

        private bool UsuariosProtected(string text) //Usuarios protegidos del sistema
        {
            return (text.Equals("11") || text.Equals("22") || text.Equals("00"));
        }

        private void TransformaDNI(TextBox txbDNI)
        {
            string[] aux = txbDNI.Text.Split('-');
            if (aux.Length > 1)
            {
                txbDNI.Text = aux[0] + aux[1];
            }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void cbxStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbxStatus.SelectedIndex)
            {
                case 0:
                    tipo = 0;
                    break;
                case 1:
                    tipo = 2;
                    break;
                case 2:
                    tipo = 1;
                    break;
                default: goto case 0;

            }
        }

        private void btnOtro_Click(object sender, EventArgs e)
        {
            txbTlf.Text = LNyAD.NumeroDisponible();
        }
    }
}
