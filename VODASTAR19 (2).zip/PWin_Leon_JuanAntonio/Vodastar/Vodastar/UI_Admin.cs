﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso.Entidades;

namespace Vodastar
{
    public partial class UI_Admin : Form
    {
        UI_VerClientes verClientes;
        UI_tarifas verTarifas;
        Cliente usuario;
        public Cliente Usuario
        {
            get
            {
                return usuario;
            }

            set
            {
                usuario= value;
            }
        }


        public UI_Admin()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClient_Click(object sender, EventArgs e)
        {
            verClientes = new UI_VerClientes();
            verClientes.QuienSoy = usuario;
            verClientes.ShowDialog();
        }

        private void btnTarifa_Click(object sender, EventArgs e)
        {
            verTarifas = new UI_tarifas();
            verTarifas.ShowDialog();
        }

        UI_DatConsumos consumos;

        private void btnConsumo_Click(object sender, EventArgs e)
        {
            consumos = new UI_DatConsumos(0);
            consumos.Text = "Consumos";
            consumos.Cliente = new Cliente();
            consumos.ShowDialog();

        }

        private void UI_Admin_Load(object sender, EventArgs e)
        {
            MinimumSize = this.Size;
            MaximumSize = this.Size;
        }
    }
}
