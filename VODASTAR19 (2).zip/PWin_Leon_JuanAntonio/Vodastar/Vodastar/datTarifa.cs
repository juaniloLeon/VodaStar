﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;


namespace Vodastar
{
    public partial class datTarifa : Form
    {

        Tarifa tarifa;

        public Tarifa Tarifa
        {
            get
            {
                return tarifa;
            }

            set
            {
                tarifa = value;
            }
        }


        public datTarifa()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double variable, fijo;
            string varT, fijT;
            string[] aux;

            if(MessageBox.Show("¿Desea guardar la tarifa?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if(txbFijo.Text.Equals(string.Empty)|| txbNombre.Text.Equals(string.Empty)|| txbVar.Text.Equals(string.Empty))
                {
                    MessageBox.Show("Todos los campos son obligatorios", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;

                }
                aux = txbFijo.Text.Split('.');

                if (aux.Length > 1)
                {
                    fijT = aux[0] + "," + aux[1];
                }
                else fijT = txbFijo.Text;

                aux = txbVar.Text.Split('.');

                if (aux.Length > 1)
                {
                    varT = aux[0] + "," + aux[1];
                }
                else varT = txbVar.Text;


                if (Double.TryParse(fijT, out fijo) && Double.TryParse(varT, out variable))
                {
                    tarifa.PrecioVariable = variable;
                    tarifa.PrecioFijo = fijo;
                    tarifa.Nombre = txbNombre.Text;
                    DialogResult = DialogResult.Yes;
                }
                else
                    MessageBox.Show("El formato es incorrecto", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void datTarifa_Load(object sender, EventArgs e)
        {
            MinimumSize = this.Size;
            MaximumSize = this.Size;

            if (tarifa.IdTarifa < 0) { }
            else
            {
                txbFijo.Text = tarifa.PrecioFijo.ToString();
                txbVar.Text = tarifa.PrecioVariable.ToString();
                txbNombre.Text = tarifa.Nombre;
            }
        }
    }
}
