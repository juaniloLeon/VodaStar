﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;


namespace Vodastar
{
    public partial class UI_Login : Form
    {
        UI_Admin consolaAdmin;
        UI_DatCliente solAlta;
        UI_Cliente nextCliente;


        public UI_Login()
        {
            InitializeComponent();
        }

        private void UI_Login_Load(object sender, EventArgs e)
        {
            this.MinimumSize = this.Size;
            this.MaximumSize = this.Size;

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txbPass.Text = String.Empty;
            txbUser.Text = String.Empty;
        }

        private void btnAccess_Click(object sender, EventArgs e)
        {
            Cliente usuario=new Cliente();
            int acceso = LNyAD.Acceso(txbUser.Text, txbPass.Text);
            if (!(acceso < 0))
            {
                usuario = LNyAD.ObtenClienteVerificado(txbUser.Text);//LNyAD.ObtenClientePorDNI(txbUser.Text);

            }
            switch (acceso)
            {
                case 0: //deshabilitado
                    MessageBox.Show("Usted se encuentra de baja actualmente\nContacte con soporte para recuperar su cuenta", "Usuario deshabilitado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case 1: //admin
                    consolaAdmin = new UI_Admin();
                    consolaAdmin.Usuario = usuario;

                    consolaAdmin.ShowDialog();
                    txbPass.Text = String.Empty;

                    break;
                case 2: //user
                    nextCliente = new UI_Cliente();
                    nextCliente.QuienSoy = usuario;
                    nextCliente.ShowDialog();

                    break;
                default:
                    MessageBox.Show("Credenciales de acceso no válidas", "Error de acceso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;

            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            solAlta = new UI_DatCliente(0);
            Cliente cliente = new Cliente();
            solAlta.Cliente = cliente;


            if (solAlta.ShowDialog() == DialogResult.Yes)
            {
                LNyAD.ActualizarAnyadirRegistro(cliente);


                MessageBox.Show("Alta solicitada");
            }
        }
    }
}
