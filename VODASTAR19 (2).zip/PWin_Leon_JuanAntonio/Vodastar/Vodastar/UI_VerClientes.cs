﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogisticayAcceso;
using LogisticayAcceso.Entidades;

namespace Vodastar
{
    public partial class UI_VerClientes : Form
    {
        UI_DatCliente datCliente;
        UI_DatConsumos datConsumos;
        Cliente quienSoy;


        public Cliente QuienSoy
        {
            get
            {
                return quienSoy;
            }

            set
            {
                quienSoy = value;
            }
        }


        public UI_VerClientes()
        {
            InitializeComponent();
        }

        private void verClientes_Load(object sender, EventArgs e)
        {
            MinimumSize = this.Size;
            MaximumSize = this.Size;
            cbStatus.Items.Add("TODOS");
            cbStatus.Items.Add("ACTIVOS");
            cbStatus.Items.Add("BAJAS");
            cbStatus.Items.Add("ADMINS");

            cbStatus.SelectedIndex = 0;


            dgv.DataSource = LNyAD.ObtenerClientes();
            dgv.Columns["idClientes"].Visible = false;
            dgv.Columns["Clave"].Visible = false;
            dgv.Columns["Tipo"].Visible = false;
            dgv.Columns["Editar"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Consumos"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Borrar"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dgv.Columns["Total"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgv.Columns["Estado"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            dgv.Columns["Total"].Visible = true;

           dgv.Columns["Editar"].DisplayIndex = 0;
            dgv.Columns["Consumos"].DisplayIndex =1;
            dgv.Columns["Borrar"].DisplayIndex = 2;
            dgv.Columns["Estado"].DisplayIndex = 3;
            dgv.Columns["Nombre"].DisplayIndex = 4;
            dgv.Columns["Apellidos"].DisplayIndex = 5;
            dgv.Columns["DNI"].DisplayIndex = 6;
            dgv.Columns["eMail"].DisplayIndex = 7;
            dgv.Columns["Telefono"].DisplayIndex = 8;

  

            RellenaDatos(-1);



        }

        private void RellenaDatos(int status)
        {
            dgv.DataSource = LNyAD.ObtenerClientes(status);
            int idColCliente = dgv.Columns["idClientes"].Index;
            int idColTipo = dgv.Columns["Tipo"].Index;
            int colTotal = dgv.Columns["Total"].Index;
            

            int idColStatus = dgv.Columns["Estado"].Index;
            int aux;

            for (int i = 0; i < dgv.RowCount-1; i++)
            {
                aux =Convert.ToInt32(dgv[idColTipo, i].Value.ToString());
                switch (aux)
                {
                    case 0:
                        dgv[idColStatus, i].Value = "BAJA";
                        break;
                    case 1:
                        dgv[idColStatus, i].Value = "ADMIN";
                        break;
                    case 2:
                        dgv[idColStatus, i].Value = "ALTA";
                        break;
                }
                dgv[colTotal, i].Value = LNyAD.TotalDeTotales(dgv[idColCliente,i].Value.ToString())+"€";

            }
            dgv.Update();

        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int editar, borrar, consumos,idCOL;
            int idCliente;
            Cliente cliente;
            editar = dgv.Columns["Editar"].Index;
            borrar = dgv.Columns["Borrar"].Index;
            consumos = dgv.Columns["Consumos"].Index;
            idCOL = dgv.Columns["idClientes"].Index;


            if (e.RowIndex > -1&&e.RowIndex<dgv.RowCount-1)
            {

                string aux = dgv[idCOL, e.RowIndex].Value.ToString();
                idCliente = Convert.ToInt32(aux);
                cliente = LNyAD.ObtenClientePorID(idCliente);
                if (e.ColumnIndex==editar)//Editar
                {


                    datCliente = new UI_DatCliente(1);
                    datCliente.Text = "Editar registro";
                                    datCliente.Cliente = cliente;


                    if (datCliente.ShowDialog() == DialogResult.Yes)
                    {
                        LNyAD.ActualizarAnyadirRegistro(cliente);
                        ActualizaDGV();
                        dgv.Update();
                        dgv.Refresh();
                    }

                }
                else if (e.ColumnIndex == borrar)//Borrar
                {
                    string name = cliente.Nombre + " " + cliente.Apellidos;

                    if (cliente.IdCliente == quienSoy.IdCliente)
                    
                        MessageBox.Show("No puedes borrar al usuario activo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                    
                    else if (MessageBox.Show(("¿Seguro que desea borrar al usuario "+name + "?"), "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        if (LNyAD.TieneConsumos(cliente))
                            MessageBox.Show("No se puede eliminar al usuario, tiene consumos registrados");
                        else
                        {
                            LNyAD.BorrarCliente(cliente);
                            ActualizaDGV();
                        }
                    }

                }
                else if (e.ColumnIndex == consumos)//Consumos
                {
                    datConsumos = new UI_DatConsumos(1);
                    datConsumos.Cliente = cliente;
                    datConsumos.Text = "Consumos " + cliente.Telefono.ToString();
                    datConsumos.ShowDialog();

                }
                
           }
            
        }


        private void ActualizaDGV()
        {
            int aux = cbStatus.SelectedIndex;
            cbStatus.SelectedIndex = 0;
            cbStatus.SelectedIndex = 1;
            cbStatus.SelectedIndex = aux;

        }

        private void btnNEW_Click(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            datCliente = new UI_DatCliente(1);
            datCliente.Cliente = cliente;

            if (datCliente.ShowDialog() == DialogResult.Yes)
            {
                
                LNyAD.ActualizarAnyadirRegistro(cliente);
                dgv.Update();
                dgv.Refresh();
                ActualizaDGV();
            }
            


        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            int status = cbStatus.SelectedIndex;
            switch (status)
            {
                case 0: //TODOS
                    dgv.Columns["Estado"].Visible = true;
                    dgv.DataSource = LNyAD.ObtenerClientes();
                    RellenaDatos(-1);
                    
                    break;
                case 1://Activos 2
                    dgv.Columns["Estado"].Visible = false;
                    dgv.DataSource = LNyAD.ObtenerClientes(2);
                    RellenaDatos(2);
                    break;
                case 2://Bajas
                    dgv.Columns["Estado"].Visible = false;
                    dgv.DataSource = LNyAD.ObtenerClientes(0);
                    RellenaDatos(0);
                    break;
                case 3://Admin 1
                    dgv.Columns["Estado"].Visible = false;
                    dgv.DataSource = LNyAD.ObtenerClientes(1);
                    RellenaDatos(1);
                    break;

            }
        }
    }
}
